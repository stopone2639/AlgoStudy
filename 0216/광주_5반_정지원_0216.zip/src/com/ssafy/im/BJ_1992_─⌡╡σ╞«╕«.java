package com.ssafy.im;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BJ_1992_쿼드트리 {
	static int[][] arr;
	static StringBuilder sb= new StringBuilder();
	static int num; 
	
	public static void main(String[] args) throws Exception {
		//System.setIn(new FileInputStream("input_BJ_1992_쿼드트리.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		StringTokenizer st;
		int N = Integer.parseInt(br.readLine());
		arr = new int[N][N];
		for (int i = 0; i < N; i++) {
			String str = br.readLine();
			for (int j = 0; j < N; j++) {
				arr[i][j] = str.charAt(j) - '0';
			}
		}	
		Quad(0, 0, N);
		System.out.println(sb.toString());
	}
	static void Quad(int x , int y , int N) {
		if(check(x,y,N)) {
			sb.append(arr[x][y]);
		} else {
			sb.append("(");
			int mid = N/2;
			Quad(x,y, mid);//왼쪽위
			Quad(x,y +mid , mid); //오른쪽위
			Quad(x+mid, y, mid);// 왼쪽아래
			Quad(x+mid, y+mid, mid); // 오른쪽아래
			sb.append(")");
		}
	}
	static boolean check(int x, int y, int N) {
		num = arr[x][y];
		for (int i = x; i < x+ N; i++) {
			for (int j = y; j < y+ N; j++) {
				if(arr[i][j] != num) {
					return false;
				}
			}
		}
		return true;
	}
}
