package com.ssafy.im;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

import sun.util.locale.StringTokenIterator;

public class D2_2001_파리퇴치 {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		System.setIn(new FileInputStream("input_D2_ 2001_파리퇴치.txt"));
		Scanner sc = new Scanner(System.in);
		
		
		int Tc =sc.nextInt();
		//System.out.println(Tc);
		for (int tc = 0; tc < Tc; tc++) {
			int N = sc.nextInt();
			int M = sc.nextInt();
			//System.out.printf("%d %d\n",N,M);
			int[][] arr = new int[N][N];
			for (int i = 0; i < N; i++) { //배열에 입력
				for (int j = 0; j < N; j++) {
					arr[i][j] = sc.nextInt();
				}
			}
			/*for (int i = 0; i < N; i++) {  //배열 출력 검사
				for (int j = 0; j < N; j++) {
					System.out.printf("%d ", arr[i][j]);
				}
				System.out.println();
			}*/
			//최댓값
			int max = 0; 
			
			for (int i = 0; i <= N-M; i++) {
				for (int j = 0; j <= N-M; j++) {
					int sum = 0;
					for (int j2 = i; j2 < i+M; j2++) {
						for (int k = j; k < j+M; k++) {
							sum += arr[j2][k];	
						}
						
					}
					if(max < sum) {
						max = sum;
					}
					
				}
				
			}
			System.out.printf("#%d %d\n", tc+1, max);	
			
			
		}
		
	}

}
