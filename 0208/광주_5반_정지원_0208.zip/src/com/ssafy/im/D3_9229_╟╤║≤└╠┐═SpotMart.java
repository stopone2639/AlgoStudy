package com.ssafy.im;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class D3_9229_한빈이와SpotMart {

	public static void main(String[] args) throws NumberFormatException, IOException {
		System.setIn(new FileInputStream("input_D3_9229_한빈이와SpotMart.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int Tc = Integer.parseInt(br.readLine());
		for (int tc = 1; tc <= Tc; tc++) {
			String s = br.readLine();
			StringTokenizer st = new StringTokenizer(s);
			int N = Integer.parseInt(st.nextToken()); // 과자의 수
			int M = Integer.parseInt(st.nextToken()); // 제한 무게
			int[] snack = new int[N];        //과자
			String s1 = br.readLine();
			st = new StringTokenizer(s1);
			for (int i = 0; i < N; i++) {
				snack[i] = Integer.parseInt(st.nextToken());
			}
			int sum = 0;
			int max = 0;
			
			for (int i = 0; i < N-1; i++) {
				for (int j = i+1; j < N; j++) {
					sum = snack[i] + snack[j];
					if(sum <= M && max < sum) {
						max = sum;
					}
				}
			}
			if(max == 0) {
				max = -1;
			}
			System.out.printf("#%d %d\n", tc, max);
		}
		
	}

}
