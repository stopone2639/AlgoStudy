package com.ssafy.dto;

import java.io.Serializable;

public class NoteBook implements Serializable{
	private String notecode;
	private String model;
	private int price;
	private String company;
	
	
	public NoteBook() {
		super();
	}
	

	public NoteBook(String notecode, String model, int price, String conpany) {
		super();
		this.notecode = notecode;
		this.model = model;
		this.price = price;
		this.company = conpany;
	}

	public String getNotecode() {
		return notecode;
	}
	public void setNotecode(String notecode) {
		this.notecode = notecode;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String conpany) {
		this.company = conpany;
	}
	@Override
	public String toString() {
		return "NoteBook [notecode=" + notecode + ", model=" + model + ", price=" + price + ", conpany=" + company
				+ "]";
	}

	
}
