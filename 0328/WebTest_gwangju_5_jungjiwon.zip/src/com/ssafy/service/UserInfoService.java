package com.ssafy.service;

import com.ssafy.dao.*;
import com.ssafy.dto.*;
public class UserInfoService {
	UserInfoDao dao = UserInfoDao.getInstance();
	//로그인 
	public boolean login(String id, String pw) {
		return dao.login(id, pw);
	}
}
