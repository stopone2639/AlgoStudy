package com.ssafy.service;
import java.util.ArrayList;

import com.ssafy.dao.*;
import com.ssafy.dto.*;
public class NoteBookService {
	
	NoteBookDao dao = NoteBookDao.getInstance();
	// 생성
	public int insertNote(NoteBook dto)  throws Exception {
		return dao.insertNote(dto);
	}
	
	// 전체 조회
	public ArrayList<NoteBook> selectNote(){
		return dao.selectNote();
	}
	
	//상세 조회
	public NoteBook selectOneNote(String notecode) {
		return dao.selectOneNote(notecode);
	}
	//삭제
	public int deleteNote(String notecode) throws Exception {
		return dao.deleteNote(notecode);
	}
}
