package com.ssafy.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;
import com.ssafy.dto.UserInfo;
import com.ssafy.dao.*;
import com.ssafy.service.*;
@WebServlet("/userinfo")
public class UserInfoControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserInfoService service = new UserInfoService();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		process(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	
	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		switch (action) {
		case "login":
			login(request, response);
			break;
		case "logout":
			logout(request, response);
			break;
		default:
			break;
		}
	}
	protected void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		UserInfo dto = new UserInfo(id, pw);
		if(service.login(id, pw)) {
			HttpSession session = request.getSession();
			session.setAttribute("loginInfo", dto);
			response.sendRedirect(request.getContextPath()+"/index.jsp");
		} else {
			System.out.println("로그인에 실패 하였습니다.");
			request.setAttribute("loginerr", "아이디 또는 패스 워드가 다릅니다. 다시 로그인해 주세요");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		
	}
	
	protected void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(session.getAttribute("logint") != null) {
			session.removeAttribute("loginInfo");
		}
		session.invalidate();
		response.sendRedirect(request.getContextPath()+"/index.jsp");
	}
}
