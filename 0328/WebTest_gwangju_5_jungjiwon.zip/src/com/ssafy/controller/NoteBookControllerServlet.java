package com.ssafy.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.protocol.x.SyncFlushDeflaterOutputStream;
import com.ssafy.dto.NoteBook;
import com.ssafy.service.*;


@WebServlet("/notebook")
public class NoteBookControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	NoteBookService service = new NoteBookService();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		switch (action) {
		case "insertNote":
			insertNote(request, response);
			break;
		case "deleteNote":
			deleteNote(request, response);
			break;
		case "selectNote":
			selectNote(request, response);
			break;
		case "selectNoteOne":
			selectNoteOne(request, response);
			break;	
		case "insertNoteView":
			insertNoteView(request, response);
			break;
		case "indexView":
			indexView(request, response);
		
		default:
			break;
		}
	}
	
	

	private void indexView(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.sendRedirect(request.getContextPath()+"/index.jsp");
	}


	protected void insertNote(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String notecode = request.getParameter("noteCode");
		String model = request.getParameter("model");
		int price = Integer.parseInt( request.getParameter("price"));
		String company = request.getParameter("company");
		NoteBook dto = new NoteBook(notecode, model, price, company);
		try {
			int result = service.insertNote(dto);
			if(result == 1) {
				System.out.println("상품 등록 성공");
				response.sendRedirect(request.getContextPath()+"/Result.jsp");
			} else {
				System.out.println("상품 등록 실패");
				request.setAttribute("err", "상품 등록 처리 중 문제가 발생했습니다.");
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
		} catch (Exception e) {
			System.out.println("상품 등록 실패");
			request.setAttribute("err", "상품 등록 처리 중 문제가 발생했습니다.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}
	
	protected void deleteNote(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String notecode = request.getParameter("notecode");
		 
		try {
			int result = service.deleteNote(notecode);
			if(result == 1) {
				System.out.println("상품 삭제 성공");
				selectNote(request, response);
			} else {
				System.out.println("상품 삭제 실패");
				request.setAttribute("err", "삭제 처리 중 문제가 발생했습니다.");
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
		} catch (Exception e) {
			System.out.println("상품 삭제 실패");
			request.setAttribute("err", "삭제 처리 중 문제가 발생했습니다.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}
	
	protected void selectNote(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<NoteBook> list = new ArrayList<>();
		list = service.selectNote();
		request.setAttribute("list", list);
		request.getRequestDispatcher("/NoteList.jsp").forward(request, response);
	}
	
	protected void selectNoteOne(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String notecode = request.getParameter("notecode");
		NoteBook dto = service.selectOneNote(notecode);
		request.setAttribute("detailInfo", dto);
		request.getRequestDispatcher("NoteView.jsp").forward(request, response);
	}
	
	protected void insertNoteView(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect(request.getContextPath()+"/NoteRegister.jsp");
	}
}
