package com.ssafy.dao;

import com.ssafy.util.*;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.ssafy.dto.*;
public class NoteBookDao {
	DBUtil util = DBUtil.getUtil();
	private NoteBookDao() {
	}
	static NoteBookDao instance = new NoteBookDao();
	public static NoteBookDao getInstance() {
		return instance;
	}
	// 생성
	public int insertNote(NoteBook dto)  throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = util.getConnection();
			String sql = "insert into notebook values(?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			String notecode = dto.getNotecode();
			String model = dto.getModel();
			int price = dto.getPrice();
			String company = dto.getCompany();
			pstmt.setString(1, notecode);
			pstmt.setString(2, model);
			pstmt.setInt(3, price);
			pstmt.setString(4, company);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			util.close(conn, pstmt);
		}
		return 0;
	}
	// 전체 조회
	public ArrayList<NoteBook> selectNote() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<NoteBook> list = null;
		NoteBook dto = null;
		try {
			conn = util.getConnection();
			String sql ="select * from notebook";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			list = new ArrayList<NoteBook>();
			while(rs.next()) {
				String notecode = rs.getString("notecode");
				String model = rs.getString("model");
				int price =  Integer.parseInt(rs.getString("price"));
				String company = rs.getString("company");
				dto = new NoteBook(notecode, model, price, company);
				list.add(dto);
			}		
		} catch (Exception e) {
			System.out.println("[예외]" + e.getMessage());
		} finally {
			util.close(conn, stmt, rs);
		}
		return list;
	}
	//상세 조회 
	public NoteBook selectOneNote(String notecode) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		NoteBook dto = null;
		ResultSet rs = null;
		try {
			conn = util.getConnection();
			String sql ="select * from notebook where notecode=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, notecode);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				String model = rs.getString("model");
				int price =  Integer.parseInt(rs.getString("price"));
				String company = rs.getString("company");
				dto = new NoteBook(notecode, model, price, company);
				return dto;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}  finally {
			util.close(conn, pstmt, rs);
		}
		return dto;
	}
	
	//삭제
	public int deleteNote(String notecode)  throws Exception{
		Connection conn = null;
		PreparedStatement pstmt = null;
		NoteBook dto = null;
		try {
			conn = util.getConnection();
			String sql ="delete from notebook where notecode=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, notecode);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}  finally {
			util.close(conn, pstmt);
		}
		return 0;
	}
}
