package com.ssafy.dao;

import com.ssafy.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mysql.cj.protocol.Resultset;
import com.ssafy.dto.*;
public class UserInfoDao {
	DBUtil util = DBUtil.getUtil();
	private UserInfoDao() {
	}
	static UserInfoDao instance = new UserInfoDao();
	public static UserInfoDao getInstance() {
		return instance;
	}
	
	//로그인
	public boolean login(String id, String pw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		UserInfo dto = null;
		try {
			conn = util.getConnection();
			String sql ="select * from userinfo where id=? and pw=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			util.close(conn, pstmt);
		}
		return false;
	}
}
