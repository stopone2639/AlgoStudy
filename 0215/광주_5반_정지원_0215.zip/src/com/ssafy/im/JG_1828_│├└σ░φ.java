package com.ssafy.im;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.zip.InflaterInputStream;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

public class JG_1828_냉장고 {
	static class Temp implements Comparable<Temp>{
		int min;
		int max;
		
		public Temp(int min, int max) {
			super();
			this.min = min;
			this.max = max;
		}
		
		@Override
		public String toString() {
			return "Temp [min=" + min + ", max=" + max + "]";
		}

		@Override
		public int compareTo(Temp o) {
			return  o.min- this.min; //최솟 값을 내림차순
		}
		
	}
	public static void main(String[] args) throws Exception {
		//System.setIn(new FileInputStream("input_JG_1828_냉장고.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int N = Integer.parseInt(br.readLine());
		StringTokenizer st;
		Temp[] arr = new Temp[N]; //N개의 화학물질
		int minMax =0; //최솟 값중 가장 큰값
		for (int i = 0; i < N; i++) { //Temp 배열에 값들 입력
			st = new StringTokenizer(br.readLine());
			int A = Integer.parseInt(st.nextToken()); //min값
			int B = Integer.parseInt(st.nextToken());//max 값
			arr[i] = new Temp(A,B);
		}
		int cnt = 1; // 필요한 냉장고 카운트 
		Arrays.sort(arr); //최솟값 내림차순으로 정렬
		minMax = arr[0].min; //가장 큰 최솟값을 통해서 비교
		for (int i = 0; i < N; i++) { 
			if(arr[i].max < minMax) { //가장 큰 최솟값보다 다른 최댓값이 작으면 겹치는 부분이 없으므로 냉장고를 추가하기
				minMax = arr[i].min; //그리고 나서 그 화학물질의 최솟 값으로 이동
				cnt++;	
			}
		}
		StringBuilder sb = new StringBuilder(); 
		sb.append(cnt);
		System.out.println(sb.toString());

	}

}
