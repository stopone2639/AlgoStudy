package com.ssafy.im;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class D2_1954_달팽이숫자 {
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("input_D2_1954_달팽이숫자.txt"));
		Scanner sc = new Scanner(System.in);
		int Tc = sc.nextInt();
		//System.out.println(Tc);
		//우하 좌상
		int[] dx = {0, 1, 0, -1};
		int[] dy = {1, 0, -1, 0};
		for (int i = 0; i < Tc; i++) {
			int dir = 0;
			int a = 1;
			int N = sc.nextInt();
			int[][] arr = new int[N][N];
			int x = 0;
			int y = 0;
			for (int j = 0; j < N*N; j++) {
				
				arr[x][y] = a;
				a++;
				x += dx[dir];
				y += dy[dir];
				if(x < 0 || x >= N || y < 0 ||  y >= N || (arr[x][y] != 0)) {
					x -= dx[dir];
					y -= dy[dir];
					dir = (dir+1)%4;
					x += dx[dir];
					y += dy[dir];
							
				}
				
			}
			System.out.printf("#%d \n", i+1);
			for(int j = 0; j< N; j++) {
				for (int k = 0; k < N; k++) {
					System.out.print(arr[j][k]+ " ");
				}
				System.out.println();
			}
		}
	}
}
