package com.ssafy.a;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.StringTokenizer;



public class SW_3124_최소스패닝트리 {
	//간선 정보 클래스 
	static class Edge implements Comparable<Edge>{
		int from, to, w;

		public Edge(int from, int to, int w) {
			super();
			this.from = from;
			this.to = to;
			this.w = w;
		}

		@Override
		public int compareTo(Edge o) {
			// TODO Auto-generated method stub
			return this.w - o.w;
		}
		
	}
	static int[] parents;
	
	public static void makeSet(int v) {
		parents = new int[v+1];
		for (int i = 1; i <= v; i++) {
			parents[i] = i;
		}
	}
	public static int findSet(int a) {
		if(a == parents[a]) return a;
		return parents[a] = findSet(parents[a]);
	}
	public static boolean union(int a, int b) {
		int aRoot = findSet(a);
		int bRoot = findSet(b);
		if(aRoot == bRoot) return false;
		parents[bRoot] = aRoot;
		return true;
	}
//	static String s = "1\r\n" + 
//			"3 3\r\n" + 
//			"1 2 1\r\n" + 
//			"2 3 2\r\n" + 
//			"1 3 3";
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringBuilder sb = new StringBuilder();
		//br = new BufferedReader(new StringReader(s));
		int Tc = Integer.parseInt(br.readLine());
		StringTokenizer st = null;
		for (int tc = 1; tc <= Tc; tc++) {
			st = new StringTokenizer(br.readLine());
			int V = Integer.parseInt(st.nextToken());
			int E = Integer.parseInt(st.nextToken());
			Edge[] edgeList = new Edge[E];
			for (int i = 0; i < E; i++) {
				st = new StringTokenizer(br.readLine());
				int from = Integer.parseInt(st.nextToken());
				int to = Integer.parseInt(st.nextToken());
				int w = Integer.parseInt(st.nextToken());
				edgeList[i] = new Edge(from, to, w);
			}
			Arrays.sort(edgeList);
			makeSet(V);
			int result = 0;
			int cnt = 0;
			for(Edge edge:edgeList) {
				if(union(edge.from, edge.to)) {
					result += edge.w;
					if(++cnt == V-1)break;
				}
			}
			sb.append("#").append(tc).append(" ").append(result).append("\n");
		}
		System.out.println(sb);
	}
}
