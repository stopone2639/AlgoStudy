package com.ssafy.im;

import java.util.Scanner;

public class BJ_2563_색종이 {
	static final int MAX = 100;
	public static void main(String[] args) {
		String  in = "3\r\n" + 
				"3 7\r\n" + 
				"15 7\r\n" + 
				"5 2";
		
		Scanner sc = new Scanner(in);
		int N = sc.nextInt();
		int[][] arr = new int[MAX][MAX];
		int cnt = 0;
		for (int i = 0; i < N; i++) {
			int x = sc.nextInt();
			int y = sc.nextInt();
			for (int j = x; j < x+10; j++) {
				for (int k = y; k < y +10; k++) {
					arr[j][k] = 1;
				}
			}
		}
		for (int i = 0; i < MAX; i++) {
			for (int j = 0; j < MAX; j++) {
				if(arr[i][j] == 1) {
					cnt++;
				}
			}
		}
		System.out.println(cnt);
	}

}
