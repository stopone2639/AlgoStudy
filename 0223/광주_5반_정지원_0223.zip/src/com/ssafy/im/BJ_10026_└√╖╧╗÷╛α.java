package com.ssafy.im;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.StringTokenizer;

public class BJ_10026_적록색약 {
	static String str = "5\r\n" + 
			"RRRBB\r\n" + 
			"GGBBB\r\n" + 
			"BBBRR\r\n" + 
			"BBRRR\r\n" + 
			"RRRRR";
	static StringTokenizer st;
	static int N, cnt1, cnt2;
	static int[] dr = {-1, 1, 0,0}; //상하좌우
	static int[] dc = {0,0, -1, 1};
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//br = new BufferedReader(new StringReader(str));
		
		N = Integer.parseInt(br.readLine());
		char[][] arr = new char[N][N];
		char[][] arrRG = new char[N][N];
		boolean[][] visit = new boolean[N][N];
		boolean[][] visitRG = new boolean[N][N];
		cnt1 = 0;
		cnt2 = 0;
		for (int i = 0; i < N; i++) {
			String strr = br.readLine();
			for (int j = 0; j < N; j++) {
				arr[i][j] = strr.charAt(j);
			}
		}
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if(arr[i][j] == 'G') {
					arrRG[i][j] = 'R';
				} else {
					arrRG[i][j] = arr[i][j];
				}
			}
		}
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if(!visit[i][j]) {
					dfs(i, j ,arr, visit);
					cnt1++;
				}
			}
		}
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if(!visitRG[i][j]) {
					dfs(i, j ,arrRG, visitRG);
					cnt2++;
				}
			}
		}
		System.out.printf("%d %d", cnt1, cnt2);
		
		
	}
	public static void dfs(int r, int c, char[][] arr, boolean[][] visit) {
		visit[r][c] = true;
		for (int d = 0; d < 4; d++) {
			int nr = r + dr[d];
			int nc = c + dc[d];
			if(init(nr, nc) && !visit[nr][nc] && arr[nr][nc] == arr[r][c]) {
				dfs(nr, nc, arr, visit);
			}
		}
	}

	public static boolean init(int r, int c) {
		return r>=0 && r<N && c>=0 && c<N;
	}
}
