package com.ssafy.im;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.StringTokenizer;

public class JO_1681_해밀턴순환회로 {
	static String s = "5\r\n" + 
			"0 14 4 10 20 \r\n" + 
			"14 0 7 8 7 \r\n" + 
			"4 5 0 7 16 \r\n" + 
			"11 7 9 0 2 \r\n" + 
			"18 7 17 4 0";
	static boolean[] visit;
	static int[][] arr;
	static int N,min;
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//br = new BufferedReader(new StringReader(s));
		N = Integer.parseInt(br.readLine());
		arr = new int[N+1][N+1];
		visit = new boolean[N+1];
		int start = 1; //시작 지점
		for (int i = 1; i <= N; i++) { //1부터 N까지 입력
			StringTokenizer st = new StringTokenizer(br.readLine());
			for (int j = 1; j <= N; j++) {
				arr[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		min = Integer.MAX_VALUE;
		visit[start] = true; //시작지점 방문 
		dfs(start, 0, 0); 
		System.out.println(min);
	}
	public static void dfs(int start, int cnt, int weight) {
		if(cnt == N-1) { //전부다 방문하고 나면
			if(arr[start][1] == 0) return; //그 곳에서 시작점인 1로 갈 수 없으면 return
			weight += arr[start][1]; //갈 수 있으면 비용에 더해주기
			min = Math.min(weight, min);//비용을 기존 최소값과 비교 해서 작은 값 저장
			return;
		} 
		if(weight > min) return; //이미 비용이 최소값을 넘어버리면 갈 필요가 없기 때문에 return
		for (int i = 2; i <= N; i++) { //1이 시작점이라 2부터 N까지
			if(!visit[i] && arr[start][i] != 0) { //방문한 적 없고 연결 가능하면
				visit[i] = true; //방문하고
				dfs(i, cnt+1, weight + arr[start][i]); //거기로 가서 dfs 시작
				visit[i] = false; //dfs 돌리고 나서 방문 안한 처리 해주기
			}
		}
	}
}
