package com.ssafy.im;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;

public class BJ_2493_탑 { 
	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input_BJ_2493_탑.txt"));
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int[] arr = new int[N+1];
		int[] result = new int[N+1];
		Stack<Integer> stack = new Stack<>();
		for (int i = 1; i <= N; i++) {
			arr[i] = sc.nextInt();
		}
		for (int i = N; i > 0; i--) {
			if(stack.isEmpty()) {
				stack.push(i);
			} else {
				while(!stack.isEmpty() && arr[i] > arr[stack.peek()]) {
					result[stack.pop()] = i;
				}
				stack.push(i);
			}
		}
		for (int i = 1; i <= N; i++) {
			System.out.print(result[i] + " ");
		}
		
	}
	static class tower{
		int id,h;
		public tower(int id, int h) {
			this.id = id;
			this.h = h;
		}
	}
}
