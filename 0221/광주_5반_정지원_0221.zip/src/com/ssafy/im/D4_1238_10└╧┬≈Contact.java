package com.ssafy.im;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.StringTokenizer;

public class D4_1238_10일차Contact {
	static class Info {
		int index; //인덱스
		int turn; //순번
		
		public Info(int index, int turn) {
			super();
			this.index = index;
			this.turn = turn;
		}
		@Override
		public String toString() {
			return "Info [index=" + index + ", turn=" + turn + ", visit=" + visit + "]";
		}	
	}
	static int N, start, level, max; //N 글자수, start 시작 숫자, level 몇단계인지
	static StringTokenizer st;
	static ArrayList<Integer>[] adj; //인접 리스트
	static boolean[] visit; //방문여부 체크
	static ArrayList<Info> result; // 결과를 저장하는 리스트
	static String str  = "24 2\r\n" + 
			"1 17 3 22 1 8 1 7 7 1 2 7 2 15 15 4 6 2 11 6 4 10 4 2";
	public static void main(String[] args) throws Exception {
		//System.setIn(new FileInputStream("input_D4_1238_Contact.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//br = new BufferedReader(new StringReader(str));
		
		int Tc = 10;
		for (int tc = 1; tc <=Tc; tc++) {
			st = new StringTokenizer(br.readLine());
			int N = Integer.parseInt(st.nextToken()); //글자수 
			int start = Integer.parseInt(st.nextToken()); //시작 번호
			adj = new ArrayList[101]; //1~ 100 저장 할 수 있는 adj
			result = new ArrayList<Info>(); //Info 객체 리스트 생성
			level = 0; //레벨 초기화
			for (int i = 1; i <= 100; i++) { //1~ 100까지 adj 생성
				adj[i] = new ArrayList<Integer>();
			}
			visit = new boolean[101]; // 방문여부도 1~100 생성
			st = new StringTokenizer(br.readLine());
			max = Integer.MIN_VALUE;
			for (int i = 0; i < N/2; i++) {
				int from = Integer.parseInt(st.nextToken()); 
				int to = Integer.parseInt(st.nextToken());
				adj[from].add(to); 
			}
			bfs(start, 0);
			for (int i = 0; i < result.size(); i++) {
				if(result.get(i).turn == level) {
					int a = result.get(i).index;
					max = Math.max(a, max);
				}
			}
			System.out.printf("#%d %d\n", tc, max);
		}
		
	}
	static void bfs (int start, int turn) {
		Queue<Info> qu = new LinkedList<>(); 
		qu.offer(new Info(start, turn)); 
		visit[start] = true; 
		while(!qu.isEmpty()) { 
			Info current = qu.poll(); 
			result.add(new Info(current.index, current.turn));
			level = current.turn;
			int size = adj[current.index].size();
			for (int i = 0; i < size; i++) {
				int n = adj[current.index].get(i);
				if(!visit[n]) {
					visit[n] = true;
					qu.add(new Info(n, current.turn + 1));
				}
			}
		}
	}

}
