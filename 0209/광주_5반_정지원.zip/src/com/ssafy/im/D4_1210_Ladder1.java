package com.ssafy.im;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class D4_1210_Ladder1 {
	static int[][] arr;
    static int[] dx = {0, 0, -1}; //좌 우 상
    static int[] dy = {-1, 1 , 0};
    static int N = 100;
    static int answer;
    static int x, y;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("input_D4_1210_Ladder1.txt"));
		Scanner sc = new Scanner(System.in);
		int Tc = 10;
		for (int tc = 1; tc <= Tc; tc++) {
			int tcNum = sc.nextInt();
			arr  = new int[N][N];
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					arr[i][j] = sc.nextInt();
					if (arr[i][j] == 2) {
						x = i;
						y = j;
					}
				}
			}
			while(true) {
				if (x == 0) {
					answer = y;
					break;
				}
				for (int i = 0; i < 3; i++) {
					int nx = x + dx[i];
					int ny = y + dy[i];
					if(nx >= 0 && nx < N && ny >= 0 && ny < N && arr[nx][ny] == 1) {
                        arr[x][y] = 0;
 						x = nx;
						y = ny;
					}
				}
			}
			System.out.printf("#%d %d", tcNum, answer);
			System.out.println();
		}
		}
	}
	
	

