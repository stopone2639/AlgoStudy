package com.ssafy.im;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Iterator;
import java.util.StringTokenizer;

import javax.swing.plaf.synth.SynthSplitPaneUI;

public class D4_7465_창용마을무리의개수 {
	static StringTokenizer st;
	static int[] parents;
	static int N, M;
	public static void main(String[] args) throws Exception {
		//테스트용 셋인
		//System.setIn(new FileInputStream("input_D4_7465.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int Tc = Integer.parseInt(br.readLine());
		for (int tc = 1; tc <= Tc; tc++) {
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			parents = new int[N+1];
			makeSet();
			for (int i = 0; i < M; i++) {
				st = new StringTokenizer(br.readLine());
				int a = Integer.parseInt(st.nextToken());
				int b= Integer.parseInt(st.nextToken());
				union(a,b);
			}
			HashSet<Integer> set1 = new HashSet<>();
			
			for (int i = 1; i <= N; i++) {
				set1.add(parents[i]);
			}
			System.out.printf("#%d %d", tc, set1.size());
			System.out.println();
		}
	}
	public static void makeSet() {
		for (int i = 1; i <= N; i++) {
			parents[i] = i;
		}
	}
	public static int findSet(int a) {
		if(parents[a] == a) return a;
		return parents[a] = findSet(parents[a]);
		
	}
	public static boolean union(int a, int b) {
		int aRoot = findSet(a);
		int bRoot = findSet(b);
		if(aRoot == bRoot) return false;
		parents[bRoot] = aRoot;
		for (int i = 1; i <= N; i++) {
			if(parents[i] == bRoot) {
				parents[i] = aRoot;
			}
		}
		return true;
	}

}
