package com.ssafy.im;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class BJ_1987_알파벳 {
	static int[] dr = {-1, 1 , 0 , 0}; //상하좌우
	static int[] dc = {0, 0 ,- 1, 1};
	static int R, C, max;
	
	static char[][] arr;
	public static void main(String[] args) throws Exception {
		//System.setIn(new FileInputStream("input_BJ_1987_알파벳.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		R = Integer.parseInt(st.nextToken());
		C = Integer.parseInt(st.nextToken());
		arr = new char[R][C];
		for (int i = 0; i < R; i++) {
			String s = br.readLine();
			for (int j = 0; j < C; j++) {
				arr[i][j] = s.charAt(j);
			}
		}
		HashSet<Character> hs = new HashSet<>();
		hs.add(arr[0][0]);
		max = 1;
		alphabet(0,0, 1, hs);
		System.out.println(max);
		
	}
	public static void alphabet(int r, int c, int cnt, HashSet<Character> hs) {
		for (int i = 0; i < 4; i++) {
			int nr = r + dr[i];
			int nc = c + dc[i];
			if(nr < 0 || nr >= R || nc< 0 || nc >=C) {
				continue;
			}
			if(hs.contains(arr[nr][nc])) {
				max = Math.max(max, cnt);
			} else {
				hs.add(arr[nr][nc]);
				alphabet(nr, nc, cnt + 1, hs);
				hs.remove(arr[nr][nc]);
			}
			
		}
		
		
	}

}
