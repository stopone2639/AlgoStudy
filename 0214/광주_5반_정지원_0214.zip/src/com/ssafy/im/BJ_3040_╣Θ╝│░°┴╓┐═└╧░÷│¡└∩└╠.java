package com.ssafy.im;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class BJ_3040_백설공주와일곱난쟁이 {
	static int[] arr1, arr2;
	static int sum;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("input_BJ_3040_백설공주와일곱난쟁이.txt"));
		Scanner sc = new Scanner(System.in);
		int N = 9; //처음 난쟁이 수 
		arr1 = new int[9]; // 처음난쟁이 담을 배열
		for (int i = 0; i <9; i++) { //배열에 처음 9 난쟁이 담기
			arr1[i] = sc.nextInt();
		}
		arr2 = new int[7]; //구별 후 7난쟁이 담을 배열
		comb(0,0); // 조합 메서드
	}
	
	public static void comb(int cnt, int start) { 
		if(cnt == 7) { //조합 7개 선택
			sum = 0; //7난쟁이의 합
			for (int i = 0; i < 7; i++) { //다 더해주고
				sum += arr2[i];
			}
			if(sum == 100) { //만약 합이 100이면
				for (int i = 0; i < 7; i++) { //난쟁이 출력
					System.out.println(arr2[i]);
				}
			}
			return;
		}
		for (int i = start; i < 9; i++) { //start부터 시작
			arr2[cnt] = arr1[i]; // 값을 선택하고
			comb(cnt + 1, i+1); // 다음 조합으로
		}
	}
}
